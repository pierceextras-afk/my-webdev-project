# Read Me First

This folder is a **template/example**, not an exact map of what your final
project must look like.

Use it to understand common naming patterns, file organization, and how GitHub
Pages finds your site. Your actual project will probably be different depending
on the Bootstrap theme you choose, how many professional pages you create, where
you place your files, how many CSS files you use, whether your pages are in an
`html` folder or the root folder, and what your web app needs.

In other words: do not try to make your project match this folder perfectly.
Use this as a starting point for understanding structure.

## What This Template Is Showing You

This template gives one possible structure:

```text
project-folder/
  READ_ME_FIRST.md
  html/
    index.html
    scratch.html
  css/
    scratch.css
  js/
  assets/
```

Your project might have more files, fewer files, or different folders. For
example, many Bootstrap themes include folders such as `assets`, `vendor`,
`css`, `js`, `img`, or `scss`. That is normal.

The important idea is that your links must match your real file locations.

For example:

- If `scratch.html` is inside an `html` folder, the hosted URL might look like
  `https://yourusername.github.io/repository-name/html/scratch.html`
- If `scratch.html` is in the main/root folder, the hosted URL might look like
  `https://yourusername.github.io/repository-name/scratch.html`

When you submit your project, submit the **online GitHub Pages URL**, not a
local file path. Your submitted URL should start with `https://`, not
`file:///`.

## Required Pieces Of The Final Project

Your final website must be hosted online, usually with GitHub Pages.

Your site should look professional. A Bootstrap theme is recommended because it
can help with layout, spacing, typography, and responsive design. You may still
customize the theme, but avoid distracting or hard-to-read design choices such
as harsh color combinations, unreadable text, broken layouts, or distracting
backgrounds.

Your site must not have broken content. Before submitting, click every link and
check every image, video, icon link, navigation item, and embedded item.

Your site must include a resume section written in HTML. Do not submit the
resume only as a PDF, Word document, or Google Doc. A good resume section usually
includes education, work experience, skills, and possibly awards, honors, or
other accomplishments.

## From-Scratch Page

You need one page created from a blank HTML file. This is often called
`scratch.html`, but you may name it something else if your links and submitted
URL are correct.

This page should not be copied from your Bootstrap theme. It is meant to show
that you can write HTML and CSS yourself.

Your from-scratch page must include:

- An ordered list with an unordered list inside it, or an unordered list with an
  ordered list inside it
- At least one image that did not come from the Bootstrap theme
- An embedded YouTube video
- An on-page anchor
- A custom background color or background image
- At least three `div` elements used for positioning and styling content
- A live, interactive embedded Tableau graph, not just a screenshot
- Navigation back to your professional-looking pages
- A link to your AI-created web app page

Graduate students must also link from the scratch page to their extra required
page.

## Custom CSS For The From-Scratch Page

You need to create and link your own stylesheet for the from-scratch page. In
this template, that file is shown as `css/scratch.css`, but your project may use
a different file name or folder.

Your custom stylesheet should include:

- At least four style definitions
- At least one style that specifies font color
- At least one style that specifies font family
- Styles that help position and style your `div` elements

Make sure the stylesheet is actually linked to your HTML page and visibly
affects the page.

## AI Web App Page

You also need a small web app created in collaboration with AI. This could be a
game, generator, simulator, quiz, tool, or another interactive idea.

Examples include:

- Riddle generator
- Joke generator
- Number guessing game
- Snake game
- Wordle-style game
- Simulator
- Video game

Try to keep the app in a single HTML page, with the HTML, CSS, and JavaScript
together on that page. The app should be linked from your from-scratch page.

The goal is not just to copy whatever AI gives you on the first try. Iterate,
edit, test, and improve it so the final app feels like something you helped
shape.

## Before You Submit

Use the grading questions as a checklist:

- Open your hosted site online, not just the local files on your computer.
- Test your submitted scratch-page URL on another browser or device.
- Make sure the URL starts with `https://`.
- Click every link on every page.
- Check every image, video, background image, icon, and embedded item.
- Confirm your resume is HTML and is complete enough to be useful.
- Confirm your from-scratch page was made from a blank HTML file.
- Confirm your custom CSS file is linked and working.
- Confirm your Tableau graph is interactive.
- Confirm your scratch page links to your professional pages and your web app.
- Be honest when answering the self-grading questions.

This template is here to help you avoid common setup and naming problems. Your
finished project should reflect your own pages, topic, Bootstrap theme,
organization, and creative choices.
